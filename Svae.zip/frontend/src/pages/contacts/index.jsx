import { useSearchParams } from "react-router-dom";
import SearchForm from "../../comp/search-form";
import UserList from "../../comp/user-list";
import { useEffect, useState } from "react";

function Contacts() {
  //for the search params
  const [search, setSearch] = useSearchParams({
    q: "",
  });

  //for the contacts
  const [contacts, setContacts] = useState({
    [user]: "You",
    ...JSON.parse(localStorage.getItem("+contacts+mwc+") || "{}"),
  });

  //for the search function
  const [isActive, setIsActive] = useState(
    Object.keys(contacts).map(() => true)
  );

  //set all user to active if the userlist data change
  useEffect(
    () => setIsActive(Object.keys(contacts).map(() => true)),
    [contacts]
  );

  //remove user from list and storage
  function deleteUser(id) {
    if (id == user) return;
    const oldUsers = { ...contacts };
    delete oldUsers[id];
    //update UI
    setContacts(oldUsers);
    //store
    localStorage.setItem("+contacts+mwc+", JSON.stringify(oldUsers));
  }

  //refresh the username with the new username and save it
  async function refresh(id) {
    if (id == user) return;
    const oldUsers = { ...contacts };
    oldUsers[id] = await await API.get("name", id);
    //update UI
    setContacts(oldUsers);
    //store
    localStorage.setItem("+contacts+mwc+", JSON.stringify(oldUsers));
  }

  return (
    <div className="container">
      <br />
      <SearchForm
        search={search}
        setSearch={setSearch}
        onInput={(e) => {
          //search
          const search = e.target.value.toLowerCase();
          setIsActive(
            Object.keys(contacts).map((key, i) =>
              searchItem(search, contacts[key])
            )
          );
        }}
        onSubmit={(e) => log(e)}
      />
      <br />
      <UserList
        userListData={Object.keys(contacts)
          .filter((x, i) => isActive[i])
          .map((key) => {
            //render the userlist
            return { id: key, name: contacts[key] };
          })}
        deleteUser={deleteUser}
        refresh={refresh}
      />
    </div>
  );
}
export default Contacts;

//retur if the username include the search
function searchItem(search, name) {
  return name.toLocaleLowerCase().includes(search);
}
