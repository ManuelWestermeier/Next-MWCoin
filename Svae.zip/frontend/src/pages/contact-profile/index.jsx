import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import MediaShortText from "../../comp/@media-short-text";
import ProfileMenu from "../../comp/profile/profile-menue";
import DescriptionText from "../../comp/profile/description-text";
import UserData from "../../comp/profile/user-data";

//render the profile
function ContactProfile() {
  const { id } = useParams();
  const [data, setData] = useState({
    name: "loading...",
    date: new Date().toDateString(),
    mail: "x@x",
    tel: "++xxxxx",
    website: "https://www.example.com",
    description: "Hello",
  });
  //Set The Real Name & Date
  useEffect(() => {
    async function getData() {
      const _data = await API.get("user-data", id);
      if (!_data) return log("err");
      setData(_data);
    }
    getData();
  }, []);

  return (
    <div className="container">
      <br />
      <ProfileMenu id={id} name={data.name} />
      <h1>
        <MediaShortText text={data.name} maxWidth={50} />
      </h1>
      <UserData data={data} />
      <DescriptionText description={data.description} />
    </div>
  );
}

export default ContactProfile;
