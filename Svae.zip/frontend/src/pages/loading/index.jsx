import LoadingSpinner from "../../comp/loading-spinner";

function LoadingPage() {
  return (
    <div
      className="home"
      style={{ height: "100dvh" }}
    >
      <LoadingSpinner />
    </div>
  );
}
export default LoadingPage;
