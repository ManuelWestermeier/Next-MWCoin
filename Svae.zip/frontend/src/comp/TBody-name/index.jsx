import MediaShortText from "../@media-short-text";
import { Link } from "react-router-dom";

function TBodyName({ id, name }) {
  return (
    <td>
      {id == user ? (
        <Link to="/profile/edit">
          <MediaShortText text={name} maxWidth={30} />
        </Link>
      ) : (
        <Link to={id + "/profile"}>
          <MediaShortText text={name} maxWidth={30} />
        </Link>
      )}
    </td>
  );
}
export default TBodyName;
