import { Link } from "react-router-dom";

//The donate headline
export default function DonateHeadline({ money, id, name }) {
  return (
    <h3>
      Donate {money} {money == 1 ? "MWCoin" : "MWCoins"} to{" "}
      <Link to={`/contacts/${id}/profile`}>{name}</Link> (
      {!!JSON.parse(localStorage.getItem("+contacts+mwc+") || "{}")?.[id] ? (
        "in contacts"
      ) : (
        <Link to={`/contacts/add/${id}`}>Add To Contacts</Link>
      )}
      )
    </h3>
  );
}