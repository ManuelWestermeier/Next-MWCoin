//The Form CheckBox
export default function DonateCheck({ setContinue, Continue, name, money }) {
  return (
    <div className="mb-3 form-check">
      <input
        type="checkbox"
        className="form-check-input"
        id="exampleCheck1"
        onChange={(e) => setContinue(e.target.checked)}
        defaultChecked={Continue}
      />
      <label className="form-check-label" htmlFor="exampleCheck1">
        Do you want to donate {money} MWC to {name}?
      </label>
    </div>
  );
}
