//description text
export default function DescriptionText({ description }) {
  return (
    <p>
      {description.split("\n").map((line, i) => {
        return (
          <span key={i}>
            {line}
            <br />
          </span>
        );
      })}
    </p>
  );
}
