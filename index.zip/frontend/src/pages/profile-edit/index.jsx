import { useEffect, useState } from "react";
import LoadingSpinner from "../../comp/loading-spinner";

function ProfileEdit() {
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState({
    name: "",
    date: "",
    mail: "",
    tel: "",
    website: "",
    description: "",
  });
  //Set The Real Name & Date
  useEffect(() => {
    async function getData() {
      const _data = await API.get("user-data", user);
      if (!_data) return log("err");
      setData(_data);
      setIsLoading(false);
    }
    getData();
  }, []);

  return isLoading ? (
    <LoadingSpinner />
  ) : (
    <div className="container">
      <br />
      <input
        onBlurCapture={(e) => {
          API.say("change-name", e.target.value);
        }}
        className="form-control me-2"
        type="text"
        style={{ fontSize: "30px" }}
        defaultValue={data.name}
        placeholder="name..."
      />
      <hr />
      <p>{data.date}</p>
      <hr />
      <input
        onBlurCapture={(e) => {
          API.say("change-email", e.target.value);
        }}
        className="form-control me-2"
        type="email"
        defaultValue={data.mail}
        placeholder="email..."
      />
      <hr />
      <input
        onBlurCapture={(e) => {
          API.say("change-tel", e.target.value);
        }}
        className="form-control me-2"
        type="tel"
        defaultValue={data.tel}
        placeholder="phone number..."
      />
      <hr />
      <input
        onBlurCapture={(e) => {
          API.say("change-website", e.target.value);
        }}
        className="form-control me-2"
        type="text"
        defaultValue={data.website}
        placeholder="website url..."
      />
      <hr />
      <textarea
        onBlurCapture={(e) => {
          API.say("change-description", e.target.value);
        }}
        defaultValue={data.description}
        onInput={(e) => {
          e.target.style.height = e.target.scrollHeight + "px";
        }}
        placeholder="description..."
        className="form-control me-2"
      ></textarea>
      <hr />
      <button
        onClick={(e) =>
          setTimeout(() => {
            document.location.hash = "#/contacts/" + user + "/profile";
          }, 300)
        }
        className="btn btn-danger"
      >
        OK
      </button>
    </div>
  );
}

export default ProfileEdit;
