import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";

function ContactsAdd() {
  const { id } = useParams();
  const [name, setName] = useState(id);

  //Set The Real Name
  useEffect(() => {
    if (id == user) return setName("You");
    async function getName() {
      const response = await API.get("name", id);
      setName(response);
    }
    getName();
  }, []);

  return (
    <div className="container">
      <br />
      <h1>
        Do You Want To Add{" "}
        <Link to={"/contacts/" + id + "/profile"}>{name}</Link>?
      </h1>
      <AskButtons id={id} name={name} />
    </div>
  );
}

export default ContactsAdd;

function AskButtons({ name, id }) {
  return (
    <>
      <button
        onClick={(e) => {
          AddContact(id, name);
        }}
        className="btn-primary btn"
        style={{ margin: "10px" }}
        disabled={!(name != "ERROR : USER DONT EXIST" && name != user)}
      >
        Yes
      </button>
      <button
        onClick={(e) => {
          document.location.hash = "#/contacts";
        }}
        className="btn btn-danger"
      >
        No
      </button>
    </>
  );
}

function AddContact(id, name) {
  if (name == "ERROR : USER DONT EXIST" || id == user)
    document.location.hash = "#/contacts";
  const oldUsers = JSON.parse(localStorage.getItem("+contacts+mwc+") || "{}");
  localStorage.setItem(
    "+contacts+mwc+",
    JSON.stringify({ ...oldUsers, [id]: name })
  );
  document.location.hash = "#/contacts";
}
