import React, { useEffect, useRef, useState } from 'react'
import { useSearchParams } from "react-router-dom";

function Settings() {
  const [search, setSearch] = useSearchParams({
    u: user,
    p: localStorage.getItem("+password+mwc+")
  })
  const [err, setErr] = useState("")
  const [seeYourData, setSeeYourData] = useState(false)
  const [seeLogin, setSeeLogin] = useState(false)
  const [seeOldUsers, setSeeOldUsers] = useState(false)
  const form = useRef()

  useEffect(() => {
    setSearch({
      u: user,
      p: localStorage.getItem("+password+mwc+")
    }, { replace: true })
  }, [])

  return (
    <div className='container'>
      <br />
      <h2>
        Settings
      </h2>
      <hr />
      <h4>
        Authenticate
      </h4>
      <hr />
      <a onClick={e => setSeeYourData(see => !see)}>
        <h5 style={{
          cursor: "pointer",
          userSelect: "none",
          position: "relative"
        }}
        >
          Your User-Data
          <svg
            //hide / visible state svg
            style={{
              fill: "dodgerblue",
              transform: `rotate(${!seeYourData ? 360 : 180}deg)`,
              transition: "all 0.3s ease-in-out",
              position: "absolute",
              zIndex: 10,
              top: "0px",
              right: "5px",
            }}
            xmlns="http://www.w3.org/2000/svg"
            height="24"
            viewBox="0 -960 960 960"
            width="24"
          >
            <path d="M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z" />
          </svg>
        </h5>
      </a>
      <div style={{ wordBreak: "break-all", display: seeYourData ? "" : "none" }}>
        <p>User ID : <b>{user}</b></p>
        <p>Password : <b>{localStorage.getItem("+password+mwc+")}</b></p>
      </div>
      <hr />
      <a onClick={e => setSeeLogin(see => !see)}>
        <h5 style={{
          cursor: "pointer",
          userSelect: "none",
          position: "relative"
        }}>
          Log In
          <svg
            //hide / visible state svg
            style={{
              fill: "dodgerblue",
              transform: `rotate(${!seeLogin ? 360 : 180}deg)`,
              transition: "all 0.3s ease-in-out",
              position: "absolute",
              zIndex: 10,
              top: "0px",
              right: "5px",
            }}
            xmlns="http://www.w3.org/2000/svg"
            height="24"
            viewBox="0 -960 960 960"
            width="24"
          >
            <path d="M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z" />
          </svg>
        </h5>
      </a>
      <form
        ref={form}
        style={{ display: seeLogin ? "" : "none" }}
        onSubmit={async (e) => {
          e.preventDefault();
          //
          if (user == search.get("u")) return setErr("Cannot Change the User To Your Old User")
          //
          if (!await API.get("auth", {
            u: search.get("u"),
            p: search.get("p")
          }))
            return setErr("user or password is false");
          if (confirm("Do You Want Do Delete Your User And Log To Anoter In?")) {
            const oldUsers = JSON.parse(localStorage.getItem("next-mwc-last-users-loggen-in") ?? "[]")
            const newOLdUserItem = {
              u: window.user,
              p: localStorage.getItem("+password+mwc+")
            }
            if (!oldUsers.includes(newOLdUserItem))
              oldUsers.push(newOLdUserItem)
            localStorage.setItem("next-mwc-last-users-loggen-in", JSON.stringify(oldUsers))
            localStorage.setItem("+user+mwc+", search.get("u"))
            localStorage.setItem("+password+mwc+", search.get("p"))
          }
          window.location.reload()
        }}
      >
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">
            User ID
          </label>
          <input
            onInput={e => setSearch({
              u: e.target.value,
              p: search.get("p")
            }, { replace: true })}
            type="text"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">
            Password
          </label>
          <input
            onInput={e => setSearch({
              u: search.get("u"),
              p: e.target.value
            }, { replace: true })}
            type="text"
            className="form-control"
            id="exampleInputPassword1"
          />
        </div>
        <p style={{ color: "red" }}>{err}</p>
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>
      <hr />
      <a onClick={e => setSeeOldUsers(see => !see)}>
        <h5 style={{
          cursor: "pointer",
          userSelect: "none",
          position: "relative"
        }}
        >
          User Bevore Logged In
          <svg
            //hide / visible state svg
            style={{
              fill: "dodgerblue",
              transform: `rotate(${!seeOldUsers ? 360 : 180}deg)`,
              transition: "all 0.3s ease-in-out",
              position: "absolute",
              zIndex: 10,
              top: "0px",
              right: "5px",
            }}
            xmlns="http://www.w3.org/2000/svg"
            height="24"
            viewBox="0 -960 960 960"
            width="24"
          >
            <path d="M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z" />
          </svg>
        </h5>
      </a>
      <div style={{ wordBreak: "break-all", display: seeOldUsers ? "" : "none" }}>
        {
          JSON.parse(localStorage.getItem("next-mwc-last-users-loggen-in") ?? "[]").length == 0 ?
            <p>no user bevore logged in</p>
            : (JSON.parse(localStorage.getItem("next-mwc-last-users-loggen-in") ?? "[]") ?? []).map(({ u, p }, i) => {
              const [uname, setUname] = useState(u)

              useEffect(() => {
                //name
                API.get("name", u).then(name => setUname(name))
              }, [])

              return <div
                key={i}>
                <hr />
                <p>user : {u} ({uname})</p>
                <p>password : {p}</p>
                <hr />
              </div>
            })
        }
      </div>
      <hr />
    </div>
  )
}

export default Settings