import MoneyInput from "../donate-form-input";
import DonateCheck from "../donate-form-text";
import DonateText from "../donate-text";
import DonateFormBottom from "../donate-form-button";

//The donation form
export default function DonateForm({
  setError,
  setContinue,
  money,
  myMoney,
  change,
  setText,
  error,
  text,
  Continue,
  name,
  id,
}) {
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        setError("");
        if (!Continue) return setError("You have to toggle the confirm toggle");
        if (money <= 0) return setError("It has to cost more than 0 MWC");
        if (money > myMoney) return setError("too much MWC");
        if (id == user) return setError("you cant send money to yourselve");
        else {
          Donate(money, id, text);
        }
      }}
    >
      <MoneyInput change={change} myMoney={myMoney} />
      <DonateText setError={setError} setText={setText} text={text} />
      <DonateCheck
        Continue={Continue}
        money={money}
        name={name}
        setContinue={setContinue}
      />
      <DonateFormBottom error={error} />
    </form>
  );
}

//send the money
async function Donate(money, id, text = "") {
  //send the info to the API
  const data = await API.get("donate_money", { money, id, text });
  //Check if the data is suczess
  if (data) document.location.hash = "#/invests";
  else alert("Error please retry");
}
