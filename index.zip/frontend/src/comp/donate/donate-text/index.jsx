//The Form Textarea
export default function DonateText({ setError, setText, text }) {
  return (
    <div className="mb-3">
      <label htmlFor="exampleInputEmail1" className="form-label">
        Text (max : 200 characters)?
      </label>
      <textarea
        onInput={(e) => {
          if (e.target.value > 199) return setError("too much text");
          setText(e.target.value);
        }}
        onChange={(e) => {
          if (e.target.value > 199) return setError("too much text");
          setText(e.target.value);
        }}
        placeholder={text}
        className="form-control"
        id="exampleInputEmail1"
        aria-describedby="emailHelp"
      ></textarea>
    </div>
  );
}
