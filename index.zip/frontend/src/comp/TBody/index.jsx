import TBodyName from "../TBody-name";
import TBodyAction from "../TBody-action";

function TBody({ userListData, deleteUser, refresh }) {
  return (
    <tbody>
      {userListData.map(({ id, name }, i) => {
        //create for each user a list-item
        return (
          <tr key={id}>
            <th scope="row">{i + 1}</th>

            <TBodyName name={name} id={id} />

            <TBodyAction id={id} name={name} refresh={refresh} deleteUser={deleteUser}/>
          </tr>
        );
      })}
    </tbody>
  );
}

export default TBody;
