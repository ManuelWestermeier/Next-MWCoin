import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import DescriptionText from "../profile/description-text";

//render the invest
export default function Invest({
  data: { user = "", sender = "", money = 0, text = "", date = "", id = "" },
}) {
  const [userName, setUserName] = useState(user);
  const [senderName, setSenderName] = useState(sender);
  const [hide, setHide] = useState(true);

  //get name if in needs
  useEffect(() => {
    if (!hide == false) return;
    async function load() {
      setUserName(await API.get("name", user));
      setSenderName(await API.get("name", sender));
    }
    load();
  }, [hide]);

  return (
    <div>
      <hr />
      <p
        //change visible state
        onClick={(e) => setHide(!hide)}
        style={{
          cursor: "pointer",
          color: sender == window.user ? "#ec4e4e" : "yellowgreen",
          position: "relative",
        }}
      >
        {`${sender == window.user ? "-" : "+"}${money} (${date})`}
        <svg
          //hide / visible state svg
          style={{
            fill: "dodgerblue",
            transform: `rotate(${hide ? 360 : 180}deg)`,
            transition: "all 0.3s ease-in-out",
            position: "absolute",
            zIndex: 10,
            top: "0px",
            right: "5px",
          }}
          xmlns="http://www.w3.org/2000/svg"
          height="24"
          viewBox="0 -960 960 960"
          width="24"
        >
          <path d="M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z" />
        </svg>
      </p>
      <div /*Hide or visible Part*/ style={{ display: hide ? "none" : "" }}>
        <p>
          form <Link to={`/contacts/${sender}/profile`}>{senderName}</Link> to{" "}
          <Link to={`/contacts/${user}/profile`}>{userName}</Link>
        </p>
        <DescriptionText description={text} />
        <button
          //delete button
          className="btn btn-danger"
          onClick={(e) => {
            e.preventDefault();
            //confirm to delete
            if (!confirm("delete")) return;
            //send to the API : delete the invest
            API.say("delete-invest", id);
          }}
        >
          Delete
        </button>
      </div>
      <hr />
    </div>
  );
}
