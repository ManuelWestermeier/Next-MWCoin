const { log } = require("console");
const fs = require("fs");
const { randomBytes } = require("crypto");
const { createServer } = require("./WSNET_Framework/_server")

const sockets = {};

createServer({ port: 8888 }, async client => {

    var user = false;
    const id = randomBytes(5).toString("base64url")

    client.onGet("auth", data => {

        if (user) return;
        user = auth(data);
        if (user) {
            if (sockets[user])
                sockets[user][id] = client;
            else sockets[user] = { [id]: client };
        }

        return user;

    })

    client.onGet("createUser", () => createUser())

    client.onGet("name", id => {
        if (!user) return "!!!you are not logged in!!!";
        try {
            return fs.readFileSync("data/user-profile/" + savePath(id) + "/name.n", "utf-8") ?? "(don't exists)" + id;
        } catch (error) {
            return "ERROR : USER DONT EXIST";
        }
    })

    client.onGet("donate_money", data => {
        //checkt, auth & set the request params
        if (!user) return false;
        if (!data?.money || !data?.id) return false;
        //set params
        //money
        const money = data.money;
        if (typeof money != "number") return false;
        //check the sender money is bigger than 0
        if (money <= 0) return false;
        //id
        const id = savePath(data.id)
        //text
        const text = data?.text + "";
        if (text.length > 200) return;
        //check user & sender exits
        if (!fs.existsSync("data/user-profile/" + id + "/money.m")) return false;
        if (!fs.existsSync("data/user-profile/" + savePath(user) + "/money.m")) return false;
        //read the money
        var senderMoney = parseFloat(fs.readFileSync("data/user-profile/" + savePath(user) + "/money.m"))
        var userMoney = parseFloat(fs.readFileSync("data/user-profile/" + savePath(id) + "/money.m"))
        //chek if the result is bigger than 0
        if (senderMoney - money < 0) return false;
        senderMoney -= money;
        userMoney += money;
        fs.writeFileSync("data/user-profile/" + savePath(user) + "/money.m", senderMoney + "", "utf-8");
        fs.writeFileSync("data/user-profile/" + savePath(id) + "/money.m", userMoney + "", "utf-8");
        //Push the invest
        const invest = {
            id: randomBytes(10).toString("base64url"),
            user: id,
            sender: user,
            money,
            text,
            date: new Date().toDateString() + " " + new Date().toLocaleTimeString()
        }
        //write the invest
        //sender
        const senderInvest = JSON.parse(fs.readFileSync("data/user-profile/" + savePath(user) + "/invest.i"));
        fs.writeFileSync("data/user-profile/" + savePath(user) + "/invest.i", JSON.stringify([invest, ...senderInvest]), "utf-8");
        //user
        const userInvests = JSON.parse(fs.readFileSync("data/user-profile/" + savePath(id) + "/invest.i"));
        fs.writeFileSync("data/user-profile/" + savePath(id) + "/invest.i", JSON.stringify([invest, ...userInvests]), "utf-8");
        //send notifiction tho th user
        if (sockets?.[id])
            Object.keys(sockets?.[id]).forEach(socket_id => {
                //send the money
                sockets?.[id]?.[socket_id]?.say?.("change_money", userMoney)
                //send the invest
                sockets?.[id]?.[socket_id]?.say?.("incoming-invest", invest)
            })
        if (sockets?.[user])
            Object.keys(sockets?.[user]).forEach(socket_id => {
                //send the money
                sockets?.[user]?.[socket_id]?.say?.("change_money", senderMoney)
                //send the invest
                sockets?.[user]?.[socket_id]?.say?.("incoming-invest", invest)
            })
        //exit with answer true (sucsess)
        return true;
    })

    client.onGet("#money#", () => {
        if (!user) return 0;
        return parseFloat(fs.readFileSync("data/user-profile/" + savePath(user) + "/money.m", "utf-8") ?? "0");
    })

    client.onSay("get_money", () => {
        if (!user) return;
        const money = parseFloat(fs.readFileSync("data/user-profile/" + savePath(user) + "/money.m", "utf-8") ?? "0");
        client.say("change_money", money)
    })

    client.onGet("get_invests", () => {
        if (!user) return;
        return fs.readFileSync("data/user-profile/" + savePath(user) + "/invest.i", "utf-8");
    })

    client.onSay("delete-invest", delete_id => {
        if (!user || !delete_id) return;
        //save th new invests
        const senderInvest = JSON.parse(fs.readFileSync("data/user-profile/" + savePath(user) + "/invest.i"));
        fs.writeFileSync("data/user-profile/" + savePath(user) + "/invest.i", JSON.stringify(senderInvest.filter(({ id }) => id != delete_id)), "utf-8");
        //reload the user
        if (sockets?.[user])
            Object.keys(sockets?.[user]).forEach(socket_id =>
                sockets?.[user]?.[socket_id]?.say?.("total-reload")
            )
    })

    client.onGet("user-data", id => {
        if (!user) return false;
        var id = savePath(id)
        if (!fs.existsSync("data/user/" + id + ".ud")) return false
        return {
            name: fs.readFileSync("data/user-profile/" + id + "/name.n", "utf-8"),
            date: fs.readFileSync("data/user-profile/" + id + "/created.d", "utf-8"),
            mail: fs.readFileSync("data/user-profile/" + id + "/email.e", "utf-8"),
            tel: fs.readFileSync("data/user-profile/" + id + "/tel.t", "utf-8"),
            website: fs.readFileSync("data/user-profile/" + id + "/web.w", "utf-8"),
            description: fs.readFileSync("data/user-profile/" + id + "/descr.d", "utf-8")
        }
    })

    client.onSay("change-name", name => {
        if (!user) return;
        fs.writeFileSync("data/user-profile/" + user + "/name.n", name, "utf-8");
    })

    client.onSay("change-email", mail => {
        if (!user) return;
        fs.writeFileSync("data/user-profile/" + user + "/email.e", mail, "utf-8");
    })

    client.onSay("change-tel", tel => {
        if (!user) return;
        fs.writeFileSync("data/user-profile/" + user + "/tel.t", tel, "utf-8");
    })

    client.onSay("change-website", url => {
        if (!user) return;
        fs.writeFileSync("data/user-profile/" + user + "/web.w", url, "utf-8");
    })

    client.onSay("change-description", des => {
        if (!user) return;
        fs.writeFileSync("data/user-profile/" + user + "/descr.d", des, "utf-8");
    })

    client.onclose = () => close(user, id);
    client.onerror = () => close(user, id)

})

function close(user, id) {
    if (!user) return;
    if (sockets?.[user]?.[id]) {
        delete sockets[user][id]
        if (Object.keys(sockets?.[user]).length == 0)
            delete sockets?.[user]
    }
}

function auth(data) {

    if (!data?.u || !data?.p) return false;

    var data = {
        u: (data.u + "").split("/").join("|").split("\\").join("|"),
        p: data.p
    }

    return !((fs.existsSync("data/user/" + data.u + ".ud") ?
        fs.readFileSync("data/user/" + data.u + ".ud", "utf-8") : "")
        == data.p) ? false : data.u

}

function createUser() {

    const u = randomBytes(20).toString("base64url").split("/").join("|").split("\\").join("|")
    const p = randomBytes(30).toString("base64url")

    if (fs.existsSync("data/user/" + u + ".ud")) return false;

    fs.mkdirSync("data/user-profile/" + u);
    fs.writeFileSync("data/user-profile/" + u + "/name.n", u, "utf-8");
    fs.writeFileSync("data/user-profile/" + u + "/created.d", new Date().toDateString(), "utf-8");
    fs.writeFileSync("data/user-profile/" + u + "/money.m", "0", "utf-8");
    fs.writeFileSync("data/user-profile/" + u + "/invest.i", "[]", "utf-8");
    fs.writeFileSync("data/user-profile/" + u + "/email.e", "deault@example", "utf-8");
    fs.writeFileSync("data/user-profile/" + u + "/tel.t", "++xxxx", "utf-8");
    fs.writeFileSync("data/user-profile/" + u + "/web.w", "https://www.example.com", "utf-8");
    fs.writeFileSync("data/user-profile/" + u + "/descr.d", "Hello\nI am new!", "utf-8");
    fs.writeFileSync("data/user/" + u + ".ud", p, "utf-8");

    return { u, p }

}

function savePath(path) {
    return (path + "").split("/").join("|").split("\\").join("|")
}

process.on("uncaughtException", err => log(err))