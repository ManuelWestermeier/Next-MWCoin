import { Route, Link, Routes } from "react-router-dom";
import Home from "./pages/home";
import Contacts from "./pages/contacts";
import NavBar from "./comp/navbar";
import Footer from "./comp/footer";
import NotFound from "./pages/404";
import ContactProfile from "./pages/contact-profile";
import ContactDonate from "./pages/contact-donate";
import ContactsAdd from "./pages/contact-add";
import Profile from "./pages/profile";
import SettingsTheme from "./pages/settings-theme";
import Invests from "./pages/invest";

function App() {
  return (
    <>
      <NavBar />
      <Routes>
        <Route index element={<Home />} />
        <Route path="contacts" element={<Contacts />} />
        <Route path="contacts/:id/profile" element={<ContactProfile />} />
        <Route path="contacts/:id/donate" element={<ContactDonate />} />
        <Route path="contacts/add/:id" element={<ContactsAdd />} />
        <Route path="profile/edit" element={<Profile />} />
        <Route path="profile/settings/general" element={<h1>general</h1>} />
        <Route path="profile/settings/theme" element={<SettingsTheme/>} />
        <Route path="invests" element={<Invests/>} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
