import { Link } from "react-router-dom";
import { shareUser } from "../user-list";

function OtherUserAction({ id, refresh, deleteUser, name }) {
  return (
    <>
      <li>
        <Link to={id + "/profile"}>
          <button className="btn">Open Profile</button>
        </Link>
      </li>
      <li>
        <Link to={id + "/donate"}>
          <button className="btn">Donate</button>
        </Link>
      </li>
      <li>
        <button
          onClick={(e) => {
            refresh(id);
          }}
          className="btn"
        >
          Refresch
        </button>
      </li>
      <li>
        <button
          onClick={(e) => {
            shareUser(id, name);
          }}
          className="btn"
        >
          Share
        </button>
      </li>
      <li>
        <hr className="dropdown-divider" />
      </li>
      <li>
        <button
          onClick={(e) => {
            deleteUser(id);
          }}
          className="btn btn-danger"
        >
          Delete
        </button>
      </li>
    </>
  );
}

export default OtherUserAction;
