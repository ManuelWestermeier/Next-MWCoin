import { Link } from "react-router-dom";
import MyAction from "../Tbody-action-my-action";
import OtherUserAction from "../TBody-action-other-user-action";

function TBodyAction({ id, name, deleteUser, refresh }) {
  return (
    <td>
      <div className="nav-item dropdown">
        <button
          className="nav-link dropdown-toggle"
          role="button"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          Action
        </button>
        <ul className="dropdown-menu">
          <center>
            {id == user ? (
              <MyAction id={id} name={name} />
            ) : (
              <OtherUserAction
                id={id}
                refresh={refresh}
                deleteUser={deleteUser}
                name={name}
              />
            )}
          </center>
        </ul>
      </div>
    </td>
  );
}

export default TBodyAction;
