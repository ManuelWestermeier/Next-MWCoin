//The Form Money-Input
export default function MoneyInput({ change, myMoney }) {
  return (
    <div className="mb-3">
      <label htmlFor="moneyinput" className="form-label">
        How much MWCoins do you want to send (max : {myMoney})?
      </label>
      <input
        onInput={(e) => {
          change(e.target.value);
        }}
        onChange={(e) => {
          change(e.target.value);
        }}
        defaultValue={0}
        type="number"
        step={0.01}
        className="form-control"
        id="moneyinput"
      />
    </div>
  );
}
