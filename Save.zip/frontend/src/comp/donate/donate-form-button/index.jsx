//The Form Bottom (error ; submit button)
export default function DonateFormBottom({ error }) {
  return (
    <>
      <p style={{ color: "red", display: error == "" ? "none" : "" }}>
        Error : {error}
      </p>
      <button type="submit" className="btn btn-primary">
        Donate
      </button>
    </>
  );
}
