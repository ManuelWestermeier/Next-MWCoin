import { useEffect } from "react";

function SearchForm({ search, setSearch, onSubmit, onInput }) {
  useEffect(() => {
    onInput({ target: { value: search.get("q") } });
  }, []);
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit();
      }}
      className="d-flex"
      role="search"
    >
      <input
        onInput={(e) => {
          setSearch(
            {
              q: e.target.value,
            },
            { replace: true }
          );
          onInput(e);
        }}
        defaultValue={search.get("q")}
        name="q"
        className="form-control me-2"
        type="search"
        placeholder="Search"
        aria-label="Search"
      />
      <button className="btn btn-outline-success" type="submit">
        Search
      </button>
    </form>
  );
}
export default SearchForm;
