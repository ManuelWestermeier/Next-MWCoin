function LoadingSpinner() {
  return (
    <div
      className="spinner-border"
      style={{ width: "20vmin", height: "20vmin" }}
      role="status"
    >
      <span className="visually-hidden">Loading...</span>
    </div>
  );
}
export default LoadingSpinner;
