import TBody from "../TBody";

function UserList({
  userListData = [{ name: "", id: "" }],
  deleteUser,
  refresh,
}) {
  return (
    <table className="table table-striped table-hover">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Name</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <TBody
        userListData={userListData}
        deleteUser={deleteUser}
        refresh={refresh}
      />
    </table>
  );
}

//for sharing the user with id and name 
export function shareUser(id, name) {
  const url = new URL(document.location);
  const text = `Add ${name} to your Next MWCoin contacts`;
  url.hash = "#/contacts/add/" + id;
  try {
    navigator.share({
      url,
      text,
      title: text,
    });
  } catch (error) {
    const whatsAppURL = new URL("https://api.whatsapp.com/send");
    whatsAppURL.searchParams.set("text", text + " " + url);
    window.open(whatsAppURL);
  }
}

export default UserList;
