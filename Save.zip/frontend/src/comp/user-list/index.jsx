import MediaShortText from "../@media-short-text";
import { Link } from "react-router-dom";

function UserList({
  userListData = [{ name: "", id: "" }],
  deleteUser,
  refresh,
}) {
  return (
    //table-dark
    <table className="table table-striped table-hover">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Name</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <TBody
        userListData={userListData}
        deleteUser={deleteUser}
        refresh={refresh}
      />
    </table>
  );
}

function TBody({ userListData, deleteUser, refresh }) {
  return (
    <tbody>
      {userListData.map(({ id, name }, i) => {
        return (
          <tr key={id}>
            <th scope="row">{i + 1}</th>

            <td>
              {id == user ? (
                <Link to="/profile/edit">
                  <MediaShortText text={name} maxWidth={30} />
                </Link>
              ) : (
                <Link to={id + "/profile"}>
                  <MediaShortText text={name} maxWidth={30} />
                </Link>
              )}
            </td>

            <td>
              <div className="nav-item dropdown">
                <button
                  className="nav-link dropdown-toggle"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Action
                </button>

                <ul className="dropdown-menu">
                  <center>
                    {id == user ? (
                      <>
                        <li>
                          <Link to={id + "/profile"}>
                            <button className="btn">Open Profile</button>
                          </Link>
                        </li>
                        <li>
                          <button
                            onClick={(e) => {
                              shareUser(id, "You");
                            }}
                            className="btn"
                          >
                            Share
                          </button>
                        </li>
                        <li>
                          <hr className="dropdown-divider" />
                        </li>
                        <li>
                          <Link to={"/profile/edit"}>
                            <button className="btn btn-danger">
                              Edit Profile
                            </button>
                          </Link>
                        </li>
                      </>
                    ) : (
                      <>
                        <li>
                          <Link to={id + "/profile"}>
                            <button className="btn">Open Profile</button>
                          </Link>
                        </li>
                        <li>
                          <Link to={id + "/donate"}>
                            <button className="btn">Donate</button>
                          </Link>
                        </li>
                        <li>
                          <button
                            onClick={(e) => {
                              refresh(id);
                            }}
                            className="btn"
                          >
                            Refresch
                          </button>
                        </li>
                        <li>
                          <button
                            onClick={(e) => {
                              shareUser(id, name);
                            }}
                            className="btn"
                          >
                            Share
                          </button>
                        </li>
                        <li>
                          <hr className="dropdown-divider" />
                        </li>
                        <li>
                          <button
                            onClick={(e) => {
                              deleteUser(id);
                            }}
                            className="btn btn-danger"
                          >
                            Delete
                          </button>
                        </li>
                      </>
                    )}
                  </center>
                </ul>
              </div>
            </td>
          </tr>
        );
      })}
    </tbody>
  );
}

export function shareUser(id, name) {
  const url = new URL(document.location);
  const text = `Add ${name} to your Next MWCoin contacts`;
  url.hash = "#/contacts/add/" + id;
  try {
    navigator.share({
      url,
      text,
      title: text,
    });
  } catch (error) {
    const whatsAppURL = new URL("https://api.whatsapp.com/send");
    whatsAppURL.searchParams.set("text", text + " " + url);
    window.open(whatsAppURL);
  }
}

export default UserList;
