function MediaShortText({ text, maxWidth }) {
  return <span title={text}>{short(text, maxWidth)}</span>;
}

function short(text = "", maxWidth = 50) {
  const fontSize = parseInt(
    getComputedStyle(document.documentElement).fontSize
  );
  const percent = Math.floor(((window.innerWidth / 100) * maxWidth) / fontSize);

  var newText = "";

  for (let index = 0; index < percent - 3 > 0 ? percent - 3 : 0; index++) {
    newText += text[index] ?? "";
  }

  newText += newText.length < text.length ? "..." : "";

  return newText;
}

export default MediaShortText;
