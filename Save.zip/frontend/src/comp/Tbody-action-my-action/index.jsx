import { Link } from "react-router-dom";
import { shareUser } from "../user-list";

function MyAction({ id, name }) {
  return (
    <>
      <li>
        <Link to={id + "/profile"}>
          <button className="btn">Open Profile</button>
        </Link>
      </li>
      <li>
        <button
          onClick={(e) => {
            shareUser(id, "You");
          }}
          className="btn"
        >
          Share
        </button>
      </li>
      <li>
        <hr className="dropdown-divider" />
      </li>
      <li>
        <Link to={"/profile/edit"}>
          <button className="btn btn-danger">Edit Profile</button>
        </Link>
      </li>
    </>
  );
}

export default MyAction;
