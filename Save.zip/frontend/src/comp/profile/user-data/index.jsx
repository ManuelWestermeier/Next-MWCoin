import MediaShortText from "../../@media-short-text";

//render the profile data
export default function UserData({ data }) {
  return (
    <>
      <p>{data.date}</p>
      <hr />
      <p>
        <a href={"mailto:" + data.mail} target="_blank">
          <MediaShortText text={data.mail} maxWidth={160}/>
        </a>
      </p>
      <hr />
      <p>
        <a href={"tel:" + data.tel} target="_blank">
          <MediaShortText text={data.tel} maxWidth={160}/>
        </a>
      </p>
      <hr />
      <p>
        <a href={data.website} target="_blank">
          <MediaShortText text={data.website} maxWidth={160}/>
        </a>
      </p>
      <hr />
    </>
  );
}
