import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import { HashRouter } from "react-router-dom";
import Client from "../../WSNET_Framework/_client/index.js";
import LoadingPage from "./pages/loading/index.jsx";
import App from "./App.jsx";
import "./index.css";

//Create Th API
const API = new Client(apiurl);
window.API = API;
API.onSay("total-reload", () => window.location.reload());
API.onclose = () => window.location.reload();
API.onerror = () => window.location.reload();
//set authenticate data (user+password)
var user = localStorage.getItem("+user+mwc+");
var password = localStorage.getItem("+password+mwc+");

//render the main page
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Main />
  </React.StrictMode>
);

//set the state before initialising
var isOpen = false,
  setIsOpen = () => false;

//on websocket load
API.onopen = async () => {
  //if you arent authenticated
  if (!user || !password) {
    //create new user
    var data = await API.get("createUser");
    //retry
    if (!data) window.location.reload();

    //set the user & password
    user = data.u;
    password = data.p;

    //store them
    localStorage.setItem("+user+mwc+", data.u);
    localStorage.setItem("+password+mwc+", data.p);
    //store the userdata in the old users array
    localStorage.setItem("next-mwc-last-users-loggen-in", JSON.stringify(
      [data, ...JSON.parse(localStorage.getItem("next-mwc-last-users-loggen-in") ?? "[]")]
    ))
  }

  //check if your are authenticated
  const isAuth = await API.get("auth", { u: user, p: password });
  //if not ask for creating a new > create a new user 
  if (
    !isAuth &&
    confirm("Your User Doesn't exist\nDo You Want To Create A New?")
  ) {
    localStorage.removeItem("+user+mwc+");
    return window.location.reload();
  }

  //set the user global
  window.user = user;
  //remove the loading screen
  isOpen = true;
  setIsOpen(true);
};

//render a loading-screen or the applicaton
function Main() {
  //use the set state
  [isOpen, setIsOpen] = useState(isOpen);
  return <HashRouter>{isOpen ? <App /> : <LoadingPage />}</HashRouter>;
}
