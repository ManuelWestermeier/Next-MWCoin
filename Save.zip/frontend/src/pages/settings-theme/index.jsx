import { useEffect, useState } from "react";

function SettingsTheme() {
  const [mode, setMode] = useState(
    localStorage.getItem("theme")
      ? JSON.parse(localStorage.getItem("theme"))
      : false
  );

  useEffect(() => {
    document.documentElement.setAttribute(
      "data-bs-theme",
      mode ? "light" : "dark"
    );
    localStorage.setItem("theme", JSON.stringify(mode));
  }, [mode]);

  return (
    <div className="container home">
      <br />
      <button
        className="btn btn-primary"
        onClick={(e) => {
          setMode((m) => !m);
          /*
          if (
            document.documentElement.getAttribute("data-bs-theme") == "dark"
          ) {
            document.documentElement.setAttribute("data-bs-theme", "light");
          } else {
            document.documentElement.setAttribute("data-bs-theme", "dark");
          }
          */
        }}
      >
        Switech To Other Mode
      </button>
    </div>
  );
}
export default SettingsTheme;
