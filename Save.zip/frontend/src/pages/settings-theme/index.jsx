import { useEffect, useState } from "react";

function SettingsTheme() {
  const [mode, setMode] = useState(
    localStorage.getItem("theme")
      ? JSON.parse(localStorage.getItem("theme"))
      : false
  );

  useEffect(() => {
    //check the actual theme, toggle and store the new 
    document.documentElement.setAttribute(
      "data-bs-theme",
      mode ? "light" : "dark"
    );
    localStorage.setItem("theme", JSON.stringify(mode));
  }, [mode]);

  return (
    <div className="container home">
      <br />
      <button
        className="btn btn-primary"
        onClick={(e) => {
          setMode((m) => !m);
        }}
      >
        Switech To Other Mode
      </button>
    </div>
  );
}
export default SettingsTheme;
