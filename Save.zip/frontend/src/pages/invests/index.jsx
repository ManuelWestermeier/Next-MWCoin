import { useEffect, useState } from "react";
import Invest from "../../comp/invest";

function Invests() {
  const [money, setMoney] = useState(0);
  const [invests, setInvests] = useState([]);

  useEffect(() => {
    API.say("get_money");

    API.get("get_invests").then((invDataStr) => {
      try {
        const parsedInvData = JSON.parse(invDataStr || "[]");
        setInvests((or) => [...parsedInvData, ...or]);
      } catch (error) {}
    });
  }, []);

  API.onSay("incoming-invest", (invest) => {
    setInvests((invests) => [invest, ...invests]);
  });

  API.onSay("change_money", (m) => {
    setMoney(m);
    window.myMoney = m;
  });

  return (
    <div className="container">
      <br />
      <h1>
        {money} {money == 1 ? "MWCoin" : "MWCoins"}
      </h1>
      <hr />
      {invests.map((data, i) => (
        <Invest key={data.id} data={data} />
      ))}
    </div>
  );
}
export default Invests;
