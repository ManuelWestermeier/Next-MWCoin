import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="container home">
      <h1>Next MWCoin</h1>
      <p>Get Rich</p>
    </div>
  );
}
export default Home;
