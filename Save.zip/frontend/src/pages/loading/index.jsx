import LoadingSpinner from "../../comp/loading-spinner";

function LoadingPage() {
  return (
    <div
      //onClick={(e) => window.location.reload()}
      className="home"
      style={{ height: "100dvh" }}
    >
      <LoadingSpinner />
    </div>
  );
}
export default LoadingPage;
