import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Invests() {
  const [money, setMoney] = useState(0);
  const [invests, setInvests] = useState([]);

  useEffect(() => {
    API.say("get_money");

    API.get("get_invests").then((invDataStr) => {
      const parsedInvData = JSON.parse(invDataStr);
      setInvests((or) => [...parsedInvData, ...or]);
    });
  }, []);

  API.onSay("incoming-invest", (invest) => {
    setInvests((invests) => [invest, ...invests]);
  });

  API.onSay("change_money", (m) => {
    setMoney(m);
    window.myMoney = m;
  });

  return (
    <div className="container">
      <br />
      <h1>
        {money} {money == 1 ? "MWCoin" : "MWCoins"}
      </h1>
      <hr />
      {invests.map((data, i) => (
        <Invest key={data.id} data={data} />
      ))}
    </div>
  );
}
export default Invests;

function Invest({
  data: { user = "", sender = "", money = 0, text = "", date = "", id = "" },
}) {
  const [userName, setUserName] = useState(user);
  const [senderName, setSenderName] = useState(sender);
  const [hide, setHide] = useState(true);

  useEffect(() => {
    if (!hide == false) return;
    async function load() {
      setUserName(await API.get("name", user));
      setSenderName(await API.get("name", sender));
    }
    load();
  }, [hide]);

  return (
    <div>
      <hr />
      <p onClick={(e) => setHide(!hide)} style={{ cursor: "pointer" }}>
        {`${sender == window.user ? "-" : ""}${money} (${date})`}
        <svg
          style={{
            fill: "dodgerblue",
            transform: `rotate(${hide ? 360 : 180}deg)`,
            transition: "all 0.3s ease-in-out",
          }}
          xmlns="http://www.w3.org/2000/svg"
          height="24"
          viewBox="0 -960 960 960"
          width="24"
        >
          <path d="M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z" />
        </svg>
      </p>
      <div style={{ display: hide ? "none" : "" }}>
        <p>
          form <Link to={`/contacts/${sender}/profile`}>{senderName}</Link> to{" "}
          <Link to={`/contacts/${user}/profile`}>{userName}</Link>
        </p>
        <p>
          {text.split("\n").map((line, i) => (
            <span key={i}>
              {line}
              <br />
            </span>
          ))}
        </p>
        <button
          className="btn btn-danger"
          onClick={(e) => {
            e.preventDefault();
            if (!confirm("delete")) return;
            API.say("delete-invest", id);
          }}
        >
          Delete
        </button>
      </div>
      <hr />
    </div>
  );
}
