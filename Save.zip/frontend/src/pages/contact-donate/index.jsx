import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

function ContactDonate() {
  const { id } = useParams();
  const [money, setMoney] = useState(0);
  const [name, setName] = useState(id);
  const [Continue, setContinue] = useState(false);
  const [myMoney, setMyMoney] = useState(window.myMoney ?? 0);
  const [error, setError] = useState("");
  const [text, setText] = useState("Message...");

  useEffect(() => {
    setInterval(() => API.get("#money#").then((m) => setMyMoney(m)), 2000);
  }, []);
  //Set The Real Name
  useEffect(() => {
    if (id == user) return setName("You");
    async function getName() {
      const response = await API.get("name", id);
      setName(response);
    }
    getName();
  }, []);

  function change(v) {
    var new_money = parseFloat(v ?? "0");
    setMoney(new_money);
    if (myMoney - new_money < 0) setError(`too much MWC`);
  }

  return (
    <div className="container">
      <br />
      <button onClick={(e) => history.back()} className="btn btn-danger">
        Back
      </button>
      <br />
      <h3>
        Donate {money} {money == 1 ? "MWCoin" : "MWCoins"} to{" "}
        <Link to={`/contacts/${id}/profile`}>{name}</Link> (
        {!!JSON.parse(localStorage.getItem("+contacts+mwc+") || "{}")?.[id] ? (
          "in contacts"
        ) : (
          <Link to={`/contacts/add/${id}`}>Add To Contacts</Link>
        )}
        )
      </h3>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          setError("");
          if (!Continue)
            return setError("You have to toggle the confirm toggle");
          if (money <= 0) return setError("It has to cost more than 0 MWC");
          if (money > myMoney) return setError("too much MWC");
          else {
            Donate(money, id, text);
          }
        }}
      >
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">
            How much MWCoins do you want to send (max : {myMoney})?
          </label>
          <input
            onInput={(e) => {
              change(e.target.value);
            }}
            onChange={(e) => {
              change(e.target.value);
            }}
            defaultValue={0}
            type="number"
            step={0.01}
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">
            Text (max : 200 characters)?
          </label>
          <textarea
            onInput={(e) => {
              if (e.target.value > 199) return setError("too much text");
              setText(e.target.value);
            }}
            onChange={(e) => {
              if (e.target.value > 199) return setError("too much text");
              setText(e.target.value);
            }}
            placeholder={text}
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
          ></textarea>
        </div>
        <div className="mb-3 form-check">
          <input
            type="checkbox"
            className="form-check-input"
            id="exampleCheck1"
            onChange={(e) => setContinue(e.target.checked)}
            defaultChecked={Continue}
          />
          <label className="form-check-label" htmlFor="exampleCheck1">
            Do you want to donate {money} to {name}?
          </label>
        </div>
        <p style={{ color: "red", display: error == "" ? "none" : "" }}>
          Error : {error}
        </p>
        <button type="submit" className="btn btn-primary">
          Donate
        </button>
      </form>
    </div>
  );
}
export default ContactDonate;

async function Donate(money, id, text = "") {
  const data = await API.get("donate_money", { money, id, text });
  if (data) document.location.hash = "#/invests";
  else alert("Error please retry");
}
