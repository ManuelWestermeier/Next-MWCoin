import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import DonateForm from "../../comp/donate/donate-form";
import DonateHeadline from "../../comp/donate/donate-headline";

function ContactDonate() {
  const { id } = useParams();
  const [money, setMoney] = useState(0);
  const [name, setName] = useState(id);
  const [Continue, setContinue] = useState(false);
  const [myMoney, setMyMoney] = useState(window.myMoney ?? 0);
  const [error, setError] = useState("");
  const [text, setText] = useState("Message...");

  //Set The Real Name and the money
  useEffect(() => {
    setInterval(() => API.get("#money#").then((m) => setMyMoney(m)), 2000);
    if (id == user) return setName("You");
    async function getName() {
      const response = await API.get("name", id);
      setName(response);
    }
    getName();
  }, []);

  //handle the moneyinput
  function change(v) {
    //parse the value
    var new_money = parseFloat(v || "0") || 0;
    //set the money to use state
    setMoney((m) => new_money);
    //if the money to donate is more than the user money set un error
    if (myMoney - new_money < 0) setError(`too much MWC`);
  }

  return (
    <div className="container">
      <br />
      <button onClick={(e) => history.back()} className="btn btn-danger">
        Back
      </button>
      <br />
      <DonateHeadline name={name} id={id} money={money} />
      <DonateForm
        change={change}
        error={error}
        money={money}
        myMoney={myMoney}
        setContinue={setContinue}
        setError={setError}
        setText={setText}
        text={text}
        Continue={Continue}
        name={name}
        id={id}
      />
    </div>
  );
}

export default ContactDonate;
