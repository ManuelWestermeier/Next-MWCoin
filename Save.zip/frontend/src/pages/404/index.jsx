import { Link } from "react-router-dom";

function NotFound() {
  return (
    <div className="container home">
      <p>404 Page Not Found</p>
      <p>
        <Link to="/">Home</Link>
      </p>
    </div>
  );
}
export default NotFound;
